
Python API for 1Broker

1Broker provides Forex and CFD trading with bitcoin. They can be accessed here: https://1broker.com/m/r.php?i=10694 

# Bot-1broker
1broker automated trading engine based on MA cross strategy. (1H chart, SMA5 and SMA10)

# how to use (quickstart)
Change shared.py file: set your API token

run:

$ python main.py

# more advanced usage
shared.py: you can safely  change margin, pairs, and stop loss/take profit values.


I take no responsibility for any losses. This program weren't properly tested. Remember, you risk your own money.
