#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Basic example for a bot that uses inline keyboards.
# This program is dedicated to the public domain under the CC0 license.

import logging
from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Updater, CommandHandler, CallbackQueryHandler

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    level=logging.INFO)


def start(bot, update):
    keyboard = [[InlineKeyboardButton("Ver los productos más vendidos", callback_data='1')],
                [InlineKeyboardButton("Ver productos en promoción", callback_data='2')],
                [InlineKeyboardButton("Buscar un producto concreto", callback_data='3')],
                [InlineKeyboardButton("Contactar con un asistente humano", callback_data='4')]]

    reply_markup = InlineKeyboardMarkup(keyboard)

    #update.message.reply_text('Welcome! This is CoolGames Ninja chatbot. Please select one of the following options:', reply_markup=reply_markup)
    update.message.reply_text('Hola! Soy el ChatBot de Telegrow. ¿Como puedo ayudarte?', reply_markup=reply_markup)


def button(bot, update):
    query = update.callback_query

    bot.editMessageText(text="Selected option: %s" % query.data,
                        chat_id=query.message.chat_id,
                        message_id=query.message.message_id)


def help(bot, update):
    update.message.reply_text("Use /start to test this bot.")


def error(bot, update, error):
    logging.warning('Update "%s" caused error "%s"' % (update, error))


# Create the Updater and pass it your bot's token.
updater = Updater("315921483:AAFMviS3X7t2unf8dQkXytzO7IUS7ANSkhc")

updater.dispatcher.add_handler(CommandHandler('start', start))
updater.dispatcher.add_handler(CallbackQueryHandler(button))
updater.dispatcher.add_handler(CommandHandler('help', help))
updater.dispatcher.add_error_handler(error)

# Start the Bot
updater.start_polling()

# Run the bot until the user presses Ctrl-C or the process receives SIGINT,
# SIGTERM or SIGABRT
updater.idle()
