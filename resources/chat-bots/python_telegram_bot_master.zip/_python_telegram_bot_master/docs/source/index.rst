.. Python Telegram Bot documentation master file, created by
   sphinx-quickstart on Mon Aug 10 22:25:07 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Python Telegram Bot's documentation!
===============================================

.. toctree::
   telegram


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`


