telegram.inlinequeryresultarticle module
========================================

.. automodule:: telegram.inlinequeryresultarticle
    :members:
    :undoc-members:
    :show-inheritance:
