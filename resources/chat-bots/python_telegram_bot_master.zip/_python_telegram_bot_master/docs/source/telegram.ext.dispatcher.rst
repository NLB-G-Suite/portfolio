telegram.ext.dispatcher module
==============================

.. automodule:: telegram.ext.dispatcher
    :members:
    :undoc-members:
    :show-inheritance:
