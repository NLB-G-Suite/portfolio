telegram.inlinequeryresultcachedgif module
==========================================

.. automodule:: telegram.inlinequeryresultcachedgif
    :members:
    :undoc-members:
    :show-inheritance:
