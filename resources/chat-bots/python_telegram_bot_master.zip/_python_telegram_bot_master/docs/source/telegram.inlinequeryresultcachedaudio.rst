telegram.inlinequeryresultcachedaudio module
============================================

.. automodule:: telegram.inlinequeryresultcachedaudio
    :members:
    :undoc-members:
    :show-inheritance:
