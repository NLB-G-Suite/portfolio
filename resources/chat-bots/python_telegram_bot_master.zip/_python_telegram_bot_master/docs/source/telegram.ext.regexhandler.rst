telegram.ext.regexhandler module
================================

.. automodule:: telegram.ext.regexhandler
    :members:
    :undoc-members:
    :show-inheritance:
