telegram.inlinequeryresult module
=================================

.. automodule:: telegram.inlinequeryresult
    :members:
    :undoc-members:
    :show-inheritance:
