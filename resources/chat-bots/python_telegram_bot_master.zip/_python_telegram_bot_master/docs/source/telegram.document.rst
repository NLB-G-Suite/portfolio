telegram.document module
========================

.. automodule:: telegram.document
    :members:
    :undoc-members:
    :show-inheritance:
