telegram.audio module
=====================

.. automodule:: telegram.audio
    :members:
    :undoc-members:
    :show-inheritance:
