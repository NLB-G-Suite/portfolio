telegram.ext.jobqueue module
============================

.. automodule:: telegram.ext.jobqueue
    :members:
    :undoc-members:
    :show-inheritance:
