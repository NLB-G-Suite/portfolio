telegram.ext.stringregexhandler module
======================================

.. automodule:: telegram.ext.stringregexhandler
    :members:
    :undoc-members:
    :show-inheritance:
