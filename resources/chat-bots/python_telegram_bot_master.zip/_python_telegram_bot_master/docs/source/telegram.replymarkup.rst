telegram.replymarkup module
===========================

.. automodule:: telegram.replymarkup
    :members:
    :undoc-members:
    :show-inheritance:
