telegram.gamehighscore module
=============================

.. automodule:: telegram.gamehighscore
    :members:
    :undoc-members:
    :show-inheritance:
