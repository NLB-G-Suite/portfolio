telegram.callbackgame module
============================

.. automodule:: telegram.callbackgame
    :members:
    :undoc-members:
    :show-inheritance:
