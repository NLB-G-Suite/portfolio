telegram.ext.filters module
===========================

.. automodule:: telegram.ext.filters
    :members:
    :undoc-members:
    :show-inheritance:
