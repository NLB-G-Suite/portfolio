telegram.inlinequeryresultcontact module
========================================

.. automodule:: telegram.inlinequeryresultcontact
    :members:
    :undoc-members:
    :show-inheritance:
