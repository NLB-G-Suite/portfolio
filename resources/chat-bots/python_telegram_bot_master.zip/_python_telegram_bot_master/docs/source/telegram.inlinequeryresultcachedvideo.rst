telegram.inlinequeryresultcachedvideo module
============================================

.. automodule:: telegram.inlinequeryresultcachedvideo
    :members:
    :undoc-members:
    :show-inheritance:
