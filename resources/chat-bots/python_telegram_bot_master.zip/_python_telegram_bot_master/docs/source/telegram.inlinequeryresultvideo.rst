telegram.inlinequeryresultvideo module
======================================

.. automodule:: telegram.inlinequeryresultvideo
    :members:
    :undoc-members:
    :show-inheritance:
