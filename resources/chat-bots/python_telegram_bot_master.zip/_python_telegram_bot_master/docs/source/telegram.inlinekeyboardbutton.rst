telegram.inlinekeyboardbutton module
====================================

.. automodule:: telegram.inlinekeyboardbutton
    :members:
    :undoc-members:
    :show-inheritance:
