telegram.inlinequeryresultvenue module
======================================

.. automodule:: telegram.inlinequeryresultvenue
    :members:
    :undoc-members:
    :show-inheritance:
