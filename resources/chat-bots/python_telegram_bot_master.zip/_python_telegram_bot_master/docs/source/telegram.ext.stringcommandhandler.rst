telegram.ext.stringcommandhandler module
========================================

.. automodule:: telegram.ext.stringcommandhandler
    :members:
    :undoc-members:
    :show-inheritance:
