telegram.inlinequery module
===========================

.. automodule:: telegram.inlinequery
    :members:
    :undoc-members:
    :show-inheritance:
