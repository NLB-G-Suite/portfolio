telegram.inlinequeryresultcachedsticker module
==============================================

.. automodule:: telegram.inlinequeryresultcachedsticker
    :members:
    :undoc-members:
    :show-inheritance:
