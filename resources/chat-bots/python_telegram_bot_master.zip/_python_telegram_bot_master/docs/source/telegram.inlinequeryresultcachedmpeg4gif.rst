telegram.inlinequeryresultcachedmpeg4gif module
===============================================

.. automodule:: telegram.inlinequeryresultcachedmpeg4gif
    :members:
    :undoc-members:
    :show-inheritance:
