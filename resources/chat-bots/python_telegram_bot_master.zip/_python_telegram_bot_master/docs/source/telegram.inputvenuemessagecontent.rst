telegram.inputvenuemessagecontent module
========================================

.. automodule:: telegram.inputvenuemessagecontent
    :members:
    :undoc-members:
    :show-inheritance:
