telegram.callbackquery module
=============================

.. automodule:: telegram.callbackquery
    :members:
    :undoc-members:
    :show-inheritance:
