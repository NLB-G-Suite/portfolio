telegram.game module
====================

.. automodule:: telegram.game
    :members:
    :undoc-members:
    :show-inheritance:
