telegram.inlinequeryresultcacheddocument module
===============================================

.. automodule:: telegram.inlinequeryresultcacheddocument
    :members:
    :undoc-members:
    :show-inheritance:
