telegram.inlinequeryresultaudio module
======================================

.. automodule:: telegram.inlinequeryresultaudio
    :members:
    :undoc-members:
    :show-inheritance:
