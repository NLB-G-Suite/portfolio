telegram.inputtextmessagecontent module
=======================================

.. automodule:: telegram.inputtextmessagecontent
    :members:
    :undoc-members:
    :show-inheritance:
