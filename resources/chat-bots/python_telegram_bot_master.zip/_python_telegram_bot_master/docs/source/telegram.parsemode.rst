telegram.parsemode module
=========================

.. automodule:: telegram.parsemode
    :members:
    :undoc-members:
    :show-inheritance:
