telegram.update module
======================

.. automodule:: telegram.update
    :members:
    :undoc-members:
    :show-inheritance:
